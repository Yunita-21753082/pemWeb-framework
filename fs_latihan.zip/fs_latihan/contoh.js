{
    "nama": "John Doe",
    "npm": "123456789",
    "jurusan": "Teknik Informatika",
    "ipk": 3.5
  }
  
  const fs = require('fs');

  function tambahMahasiswa(nama, npm, jurusan, ipk) {
    const data = JSON.parse(fs.readFileSync('data.json', 'utf-8'));
    const mahasiswa = {
      "nama": nama,
      "npm": npm,
      "jurusan": jurusan,
      "ipk": ipk
    };
    data.push(mahasiswa);
    fs.writeFileSync('data.json', JSON.stringify(data));
  }
  
  function ubahMahasiswa(npm, properti, nilai) {
    const data = JSON.parse(fs.readFileSync('data.json', 'utf-8'));
    const index = data.findIndex(m => m.npm === npm);
    if (index === -1) {
      console.log(`Mahasiswa dengan NPM ${npm} tidak ditemukan`);
    } else {
      data[index][properti] = nilai;
      fs.writeFileSync('data.json', JSON.stringify(data));
      console.log(`Informasi mahasiswa dengan NPM ${npm} berhasil diubah`);
    }
  }
  
  function hapusMahasiswa(npm) {
    const data = JSON.parse(fs.readFileSync('data.json', 'utf-8'));
    const index = data.findIndex(m => m.npm === npm);
    if (index === -1) {
      console.log(`Mahasiswa dengan NPM ${npm} tidak ditemukan`);
    } else {
      data.splice(index, 1);
      fs.writeFileSync('data.json', JSON.stringify(data));
      console.log(`Informasi mahasiswa dengan NPM ${npm} berhasil dihapus`);
    }
  }
  
  function lihatMahasiswa() {
    const data = JSON.parse(fs.readFileSync('data.json', 'utf-8'));
    console.log('Daftar Mahasiswa:');
    data.forEach(m => {
      console.log(`- Nama: ${m.nama}, NPM: ${m.npm}, Jurusan: ${m.jurusan}, IPK: ${m.ipk}`);
    });
  }
  
  // Contoh penggunaan method
  tambahMahasiswa('John Doe', '123456789', 'Teknik Informatika', 3.5);
  ubahMahasiswa('123456789', 'ipk', 4.0);
  hapusMahasiswa('123456789');
  lihatMahasiswa();

contoh.json
function tambahMahasiswa(nama, npm, jurusan, ipk) {
    const fs = require('fs');
  
    // baca isi file data.json
    const data = JSON.parse(fs.readFileSync('data.json', 'utf8'));
  
    // tambahkan data mahasiswa baru ke dalam array
    data.push({
      nama: nama,
      npm: npm,
      jurusan: jurusan,
      ipk: ipk
    });
  
    // tulis ulang file data.json
    fs.writeFileSync('data.json', JSON.stringify(data, null, 2));
  
    console.log(`Mahasiswa dengan nama ${nama} telah ditambahkan ke dalam file data.json.`);
  }